package model;

public enum CategoryPremium {

    PLATA, ORO, DIAMANTE, POR_DEFINIR;
    
}
