package model;

import java.util.Calendar;

public class UserRegular extends User {

    public UserRegular(String id, String name, String nickname, Calendar singUpDate) {
        super(id, name, nickname, singUpDate);

    }
    
}
