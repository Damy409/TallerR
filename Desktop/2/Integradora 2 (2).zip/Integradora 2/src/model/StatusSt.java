package model;

public enum StatusSt {
    ACTIVE,INACTIVE;
}
