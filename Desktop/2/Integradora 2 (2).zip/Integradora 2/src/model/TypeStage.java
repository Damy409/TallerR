package model;

public enum TypeStage {
    
    INICIO, ANÁLISIS, DISEÑO, EJECUCIÓN, CIERRE, SEGUIMIENTO_Y_CONTROL;
}
