package model;

public enum CategoriesB {
    
    FANTASY, SCIENCE_FICTION, HISTORICAL_NOVEL, POR_DEFINIR;
}
