package model;

public enum Categories {

    VARIETIES, DESING, SCIENTIFIC, POR_DEFINIR;
    
}
