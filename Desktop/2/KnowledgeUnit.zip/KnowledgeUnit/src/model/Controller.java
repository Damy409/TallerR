package model;

public class Controller {

	private KnowledgeUnit[] units;

	public Controller() {

		units = new KnowledgeUnit[5];
		testCases();

	}
	
	
	public void testCases() {

		/**
		units[0] = new KnowledgeUnit("A001", "Gestion de repositorios", "Tecnico", "GitHub es una herramienta util", this);
		units[1] = new KnowledgeUnit("A002", "Gestion de equipos", "Experiencias", "Es importante definir responsabilidades claras", this);
		*/
		
	}
	
	/**
	 * Description: Method used to register Knowledge capsules 
	 * @param id Identification that each Knowledge capsule has
	 * @param description Short message that describes the Knowledge capsule
	 * @param type Type of Knowledge Unit (Technical-Experiences-Gestion-Control)
	 * @param learnedLesson Learned lesson or Knowledge unit
	 * @param status status of the Knowledge Unit
	 * @return
	 */

	public boolean registerKnowledgeUnit(String id, String description, String type, String learnedLesson, String status) {
		
		KnowledgeUnit newKnowledgeUnit = new KnowledgeUnit(id, description, type, learnedLesson, null);

		for(int i=0; i < units.length; i++){

			if(units[i] == null){

				units[i] = newKnowledgeUnit;
				return true;
			}
		}
		return false;
	}

	/**
	 * Description: Method that helps change the approval status of Knowledge capsules
	 * @param id Identification that each Knowledge capsule has
	 * @param approbation Approval status of the Knowledge capsule 
	 */
	public void approveKnowledgeUnit(int id, String approbation) {

		units[id].setStatus(approbation);

	}


	/**
	 * Description: Method created to help approve Knowledge capsules
	 * @return
	 */
	public String searchKnowledgeUnite(){

		String msg = "";

		for(int i = 0; i < units.length; i++ ){

			if(units[i]!=null){
                msg += "\n"+ (i+1) + ". " + units[i].getId();
            }
		}

		return msg;
	}

	/**
	 * Description: Method created to help show Knowledge capsules
	 * @return
	 */
	public String getAllKnowledgeUnits() {

		String msg = "";

		for(int i = 0; i < units.length; i++ ){

			if(units[i]!=null){
                msg += "\n" + units[i].toString();
            }
		}

		return msg;
	}

}
