package model;

public enum CapsuleType {

    TECNICO,GESTION,DOMINIO, EXPERIENCIAS;
    
}
