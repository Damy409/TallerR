package model;
import java.util.Calendar;


public class Controller {

	private KnowledgeUnit[] units;
	private ProjectUnit[] projects; 


	public Controller() {
	
		units = new KnowledgeUnit[25];
		projects = new ProjectUnit[10]; 
	}

	public boolean registerProject(String nombreP, String nombreC, String numeroC, double precio, String nombreCollaborator, String numeroCollaborator, int dia, int mes, int año, int dia2, int mes2, int año2){


		ProjectUnit newProjectunit  = new ProjectUnit(nombreP, nombreC, numeroC, precio, nombreCollaborator, numeroCollaborator, null, null);
	
		for(int i =0; i<units.length;i++){
			
			if(projects[i]==null){
				projects[i] = newProjectunit;
				return true;
			}
		
		}
		
		return false;

	}

	public boolean registerKnowledgeUnit(String identificacion, String descripcion, String tipo, String leccion) {

		KnowledgeUnit newKnowledgeUnit = new KnowledgeUnit(identificacion, descripcion, descripcion, leccion, leccion);

		for(int i=0; i < units.length; i++){

			if(units[i] == null){

				units[i] = newKnowledgeUnit;
				return true;
			}
		}
		return false;
        

    }

	public void approveKnowledgeUnit(int whichUnit,String approbacion){
		
		units[whichUnit].setStatus(approbacion);

	}

	public String getKnowledgeUnits(){


		String msg = "";

		for(int i = 0; i < units.length; i++ ){

			if(units[i]!=null){
                msg += "\n" + units[i].toString();
            }
		}

		return msg;
	}
}

	
