package model;

public enum CapsuleStatus {

    ACTIVE, INACTIVE;
    
}
